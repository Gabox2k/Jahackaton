# -*- coding: utf-8 -*-
import os
ANCHO, ALTO, FPS = 1280, 720, 60
BASE_DIR = os.path.dirname(os.path.dirname(__file__))
ASSETS = os.path.join(BASE_DIR, "assets")
IMAGES = os.path.join(ASSETS, "images")
SOUNDS = os.path.join(ASSETS, "sounds")
FONTS  = os.path.join(ASSETS, "fonts")
OBJETIVO_PEDIDOS=3; TIEMPO_PARTIDA=180
DINERO_X_PEDIDO=100_000; PENALIDAD_NO_ENTREGA=100_000
MAPAS=["fiesta_san_juan","mercado_4","lomiteria_guarani"]
RECETAS_POR_MAPA={
 "fiesta_san_juan":["mbeju","chipa_asador"],
 "mercado_4":["pastel_mandio","sopa_paraguaya"],
 "lomiteria_guarani":["lomito_arabe","lomito_completo"],
}
