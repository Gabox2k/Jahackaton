# -*- coding: utf-8 -*-
import os, pygame
from .. import config
def cargar_imagen(relpath, size=(64,64), color=(80,80,80)):
    ruta=os.path.join(config.IMAGES, relpath)
    if os.path.exists(ruta): return pygame.image.load(ruta).convert_alpha()
    surf=pygame.Surface(size, pygame.SRCALPHA); surf.fill(color); return surf
def cargar_fuente(nombre='pixel_font.ttf', tam=24):
    ruta=os.path.join(config.FONTS, nombre)
    try: return pygame.font.Font(ruta, tam)
    except: return pygame.font.SysFont(None, tam)
