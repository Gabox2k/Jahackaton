# -*- coding: utf-8 -*-
import os, pygame
from .. import config

class SoundManager:
    def __init__(self):
        # Mixer init tolerante
        try:
            pygame.mixer.init()
            self._ok = True
        except Exception as e:
            print("[WARN] pygame.mixer no pudo inicializarse:", e)
            self._ok = False
        self.sounds = {}
        self.music_volume = 0.6
        self.sfx_volume = 0.8

    def load_sound(self, key, relpath):
        if not self._ok: return
        path = os.path.join(config.SOUNDS, relpath)
        try:
            s = pygame.mixer.Sound(path)
            s.set_volume(self.sfx_volume)
            self.sounds[key] = s
        except Exception as e:
            print(f"[WARN] No se pudo cargar sonido {relpath}: {e}")

    def play(self, key):
        if not self._ok: return
        snd = self.sounds.get(key)
        if snd: snd.play()

    def play_music(self, relpath, loop=-1):
        if not self._ok: return
        path = os.path.join(config.SOUNDS, relpath)
        try:
            pygame.mixer.music.load(path)
            pygame.mixer.music.set_volume(self.music_volume)
            pygame.mixer.music.play(loop)
        except Exception as e:
            print(f"[WARN] No se pudo reproducir música {relpath}: {e}")

    def stop_music(self):
        if not self._ok: return
        pygame.mixer.music.stop()
