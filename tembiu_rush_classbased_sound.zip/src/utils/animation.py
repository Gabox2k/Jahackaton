# -*- coding: utf-8 -*-
class SpriteAnim:
    def __init__(self, frames, fps=8, loop=True):
        self.frames, self.fps, self.loop = frames, fps, loop
        self.t, self.idx = 0,0
    def update(self, dt):
        self.t+=dt
        if self.t>=1000/self.fps:
            self.t=0; self.idx+=1
            if self.idx>=len(self.frames): self.idx=0 if self.loop else len(self.frames)-1
    @property
    def image(self): return self.frames[self.idx]
