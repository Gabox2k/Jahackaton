# -*- coding: utf-8 -*-
import pygame, sys
from . import config
from .utils.sound_manager import SoundManager
from .game_states.menu_state import MenuState
from .game_states.instrucciones_state import InstruccionesState
from .game_states.historia_state import HistoriaState
from .game_states.mapselect_state import SeleccionMapaState
from .game_states.play_state import PlayState
from .game_states.game_over_state import GameOverState

class Game:
    def __init__(self):
        pygame.init(); self.size=(config.ANCHO, config.ALTO)
        self.pantalla=pygame.display.set_mode(self.size); pygame.display.set_caption("Tembi'u Rush")
        self.clock=pygame.time.Clock(); self._running=True; self.state=None
        # Sonidos
        self.sound = SoundManager()
        self._load_sounds()
        self.set_state('menu')

    def _load_sounds(self):
        # UI
        self.sound.load_sound("click", "ui/click.wav")
        self.sound.load_sound("hover", "ui/hover.wav")
        self.sound.load_sound("transition", "ui/transition.wav")
        self.sound.load_sound("game_over", "ui/game_over.wav")
        # Gameplay
        self.sound.load_sound("cook", "gameplay/cooking.wav")
        self.sound.load_sound("chop", "gameplay/chopping.wav")
        self.sound.load_sound("pickup", "gameplay/pickup.wav")
        self.sound.load_sound("deliver_success", "gameplay/delivery_success.wav")
        self.sound.load_sound("deliver_fail", "gameplay/delivery_fail.wav")
        self.sound.load_sound("warning", "gameplay/time_warning.wav")

    def set_state(self,name):
        if name=='menu': self.state=MenuState(self)
        elif name=='instrucciones': self.state=InstruccionesState(self)
        elif name=='historia': self.state=HistoriaState(self)
        elif name=='seleccion_mapa': self.state=SeleccionMapaState(self)
        else: raise ValueError('Estado desconocido: '+name)

    def start_game(self,mapa): self.state=PlayState(self,mapa)
    def end_game(self,ganado,saldo): self.state=GameOverState(self,ganado,saldo)
    def quit(self): self._running=False

    def loop(self):
        while self._running:
            dt=self.clock.tick(config.FPS)
            for e in pygame.event.get():
                if e.type==pygame.QUIT: self.quit()
                else: self.state.handle(e)
            self.state.update(dt); self.state.draw(self.pantalla); pygame.display.flip()
        pygame.quit(); sys.exit()

def main(): Game().loop()
if __name__=='__main__': main()
