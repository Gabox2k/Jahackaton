# -*- coding: utf-8 -*-
import time
from ..utils.asset_loader import cargar_fuente
class AlertMessage:
    def __init__(self): self.font=cargar_fuente(tam=26); self.msgs=[]
    def push(self,txt,color=(255,230,120),dur=2.5): self.msgs.append((txt,color,time.time()+dur))
    def draw(self,p):
        now=time.time(); y=80; keep=[]
        for t,c,exp in self.msgs:
            if now<=exp:
                keep.append((t,c,exp))
                p.blit(self.font.render(t,True,c),(20,y)); y+=28
        self.msgs=keep
