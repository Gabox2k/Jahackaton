# -*- coding: utf-8 -*-
from ..utils.asset_loader import cargar_fuente
class TimerDisplay:
    def __init__(self,pos): self.font=cargar_fuente(tam=28); self.pos=pos
    def draw(self,pantalla,seg):
        m=int(seg)//60; s=int(seg)%60
        lbl=self.font.render(f"{m:02d}:{s:02d}", True, (255,255,255)); pantalla.blit(lbl, self.pos)
