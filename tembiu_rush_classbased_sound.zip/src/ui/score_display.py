# -*- coding: utf-8 -*-
from ..utils.asset_loader import cargar_fuente
class ScoreDisplay:
    def __init__(self,pos): self.font=cargar_fuente(tam=28); self.pos=pos
    def draw(self,pantalla,gs): 
        lbl=self.font.render(f"₲ {gs:,}".replace(",","."), True, (255,255,255)); pantalla.blit(lbl,self.pos)
