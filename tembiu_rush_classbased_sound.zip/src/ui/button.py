# -*- coding: utf-8 -*-
import pygame
from ..utils.asset_loader import cargar_fuente

class Button:
    def __init__(self, texto, rect, on_click=None, sound=None):
        self.texto, self.rect, self.on_click = texto, pygame.Rect(rect), on_click
        self.font=cargar_fuente(tam=32); self.hover=False
        self.sound = sound  # instancia de SoundManager (opcional)

    def handle(self, e):
        if e.type==pygame.MOUSEMOTION:
            was = self.hover
            self.hover = self.rect.collidepoint(e.pos)
            if self.hover and not was and self.sound:
                self.sound.play("hover")
        elif e.type==pygame.MOUSEBUTTONDOWN and e.button==1:
            if self.rect.collidepoint(e.pos):
                if self.sound: self.sound.play("click")
                if self.on_click: self.on_click()

    def draw(self, pantalla):
        color=(90,110,130) if not self.hover else (110,140,170)
        pygame.draw.rect(pantalla, color, self.rect, border_radius=8)
        lbl=self.font.render(self.texto, True, (255,255,255))
        pantalla.blit(lbl, lbl.get_rect(center=self.rect.center))
