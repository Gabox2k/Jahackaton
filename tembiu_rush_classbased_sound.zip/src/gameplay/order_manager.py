# -*- coding: utf-8 -*-
import random
from collections import deque
class Pedido:
    def __init__(self, receta, ttl=50):
        self.receta = receta; self.ttl = ttl
    def tick(self,dt): self.ttl -= dt
    @property
    def expirado(self): return self.ttl<=0
class OrderManager:
    def __init__(self, recetas_dict, premio, penalidad):
        self.recetas = recetas_dict; self.pedidos=deque(); self.completados=0; self.saldo=0
        self.premio=premio; self.penalidad=penalidad
    def generar(self):
        self.pedidos.append(Pedido(random.choice(list(self.recetas.items()))))
    def tick(self,dt):
        for p in list(self.pedidos):
            p.tick(dt)
            if p.expirado: self.pedidos.popleft(); self.saldo -= self.penalidad
    def intentar_entregar(self, plato):
        if not self.pedidos: return False
        nombre, ings_nec = self.pedidos[0].receta
        nombres = sorted(i.nombre for i in plato.ingredientes)
        if nombres == sorted(ings_nec):
            self.pedidos.popleft(); self.completados += 1; self.saldo += self.premio; return True
        return False
