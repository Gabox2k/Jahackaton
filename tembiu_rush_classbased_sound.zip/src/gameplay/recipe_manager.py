# -*- coding: utf-8 -*-
RECETAS={
 'mbeju':['harina_mandioca','queso'],
 'chipa_asador':['harina_mandioca','huevo'],
 'pastel_mandio':['carne','harina_mandioca'],
 'sopa_paraguaya':['harina_maiz','queso'],
 'lomito_arabe':['pan_pita','carne','ensalada'],
 'lomito_completo':['pan_frances','carne','ensalada','huevo'],
}
def recetas_para_mapa(nombre_mapa, mapa_cfg):
    claves = mapa_cfg[nombre_mapa]
    return {k: RECETAS[k] for k in claves}
