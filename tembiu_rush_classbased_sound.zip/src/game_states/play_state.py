# -*- coding: utf-8 -*-
import pygame
from .. import config
from ..entities import Jugador, Estacion
from ..gameplay.recipe_manager import recetas_para_mapa
from ..gameplay.order_manager import OrderManager
from ..ui.timer_display import TimerDisplay
from ..ui.score_display import ScoreDisplay
from ..ui.alert_message import AlertMessage

class PlayState:
    def __init__(self,game,mapa):
        self.game=game; self.mapa=mapa
        self.recetas=recetas_para_mapa(mapa, config.RECETAS_POR_MAPA)
        self.orders=OrderManager(self.recetas, config.DINERO_X_PEDIDO, config.PENALIDAD_NO_ENTREGA)
        self.tiempo=config.TIEMPO_PARTIDA; self.last_spawn=0; self.alerts=AlertMessage()

        self.p1=Jugador('P1',(160,320,44,44),{'up':pygame.K_w,'down':pygame.K_s,'left':pygame.K_a,'right':pygame.K_d,'accion':pygame.K_e})
        self.p2=Jugador('P2',(1000,320,44,44),{'up':pygame.K_UP,'down':pygame.K_DOWN,'left':pygame.K_LEFT,'right':pygame.K_RIGHT,'accion':pygame.K_RETURN})

        self.estaciones=[
            Estacion('Heladera','heladera',(60,60,120,80), sound=game.sound),
            Estacion('Mesa Corte','mesa_corte',(320,100,160,80), sound=game.sound),
            Estacion('Mesa Larga','mesa_larga',(0,340,self.game.size[0],40), sound=game.sound),
            Estacion('Olla','olla',(860,100,120,80), sound=game.sound),
            Estacion('Sartén','sarten',(1000,100,120,80), sound=game.sound),
            Estacion('Platos','platos',(940,520,120,80), sound=game.sound),
            Estacion('Entrega','entrega',(60,520,160,80), sound=game.sound),
        ]

        self.timer_ui=TimerDisplay((self.game.size[0]-140,20)); self.score_ui=ScoreDisplay((self.game.size[0]-320,20))

        game.sound.play_music("ambient/kitchen_loop.ogg")

    def handle(self,e): pass

    def update(self,dt):
        keys=pygame.key.get_pressed()
        self.p1.update(keys,dt,self.estaciones,self.game.size); self.p2.update(keys,dt,self.estaciones,self.game.size)
        if keys[self.p1.teclas['accion']]: self.p1.accionar(self.estaciones)
        if keys[self.p2.teclas['accion']]: self.p2.accionar(self.estaciones)

        entrega=next(e for e in self.estaciones if e.tipo=='entrega'); platos=next(e for e in self.estaciones if e.tipo=='platos')
        if 'ENTREGAR' in entrega.buffer:
            entrega.buffer=[x for x in entrega.buffer if x!='ENTREGAR']
            if platos.buffer:
                plato=platos.buffer.pop(0)
                if self.orders.intentar_entregar(plato): 
                    self.alerts.push('¡Pedido entregado!',(140,255,160)); self.game.sound.play('deliver_success')
                else: 
                    self.alerts.push('Plato incorrecto',(255,160,140)); self.game.sound.play('deliver_fail')

        self.last_spawn += dt/1000
        if self.last_spawn>=6 and len(self.orders.pedidos)<3: self.orders.generar(); self.last_spawn=0

        self.orders.tick(dt/1000); self.tiempo -= dt/1000
        # Warning de tiempo bajo
        if int(self.tiempo)==15:
            self.game.sound.play('warning')

        if self.tiempo<=0 or self.orders.completados>=config.OBJETIVO_PEDIDOS:
            self.game.end_game(self.orders.completados>=config.OBJETIVO_PEDIDOS, self.orders.saldo)

    def draw(self,p):
        p.fill((50,70,85))
        cols={'heladera':(130,200,255),'mesa_corte':(200,160,120),'mesa_larga':(100,100,100),'olla':(240,120,120),
              'sarten':(240,150,120),'platos':(220,220,220),'entrega':(180,255,180)}
        for e in self.estaciones:
            pygame.draw.rect(p, cols.get(e.tipo,(160,160,160)), e.rect); pygame.draw.rect(p,(15,15,15),e.rect,2)
        pygame.draw.rect(p,(250,230,90), self.p1.rect); pygame.draw.rect(p,(90,210,250), self.p2.rect)
        self.timer_ui.draw(p,self.tiempo); self.score_ui.draw(p,self.orders.saldo)
        f=pygame.font.SysFont(None,24); y=60
        for ped in list(self.orders.pedidos)[:5]:
            nombre, ings=ped.receta
            p.blit(f.render(f"{nombre}: {', '.join(ings)}  ({int(ped.ttl)}s)",True,(255,255,255)),(20,y)); y+=22
        self.alerts.draw(p)
