# -*- coding: utf-8 -*-
import pygame
from .. import config
class SeleccionMapaState:
    def __init__(self,game):
        self.game=game; self.opciones=config.MAPAS; self.idx=0; self.font=pygame.font.SysFont(None,32)
    def handle(self,e):
        if e.type==pygame.KEYDOWN:
            if e.key in (pygame.K_LEFT, pygame.K_a): self.idx=(self.idx-1)%len(self.opciones)
            elif e.key in (pygame.K_RIGHT, pygame.K_d): self.idx=(self.idx+1)%len(self.opciones)
            elif e.key in (pygame.K_RETURN, pygame.K_e, pygame.K_SPACE): self.game.start_game(self.opciones[self.idx])
    def update(self,dt): pass
    def draw(self,p):
        p.fill((25,45,65)); y=200
        for i,m in enumerate(self.opciones):
            col=(255,255,255) if i==self.idx else (170,170,170)
            p.blit(self.font.render(m.replace('_',' ').title(),True,col),(self.game.size[0]//2-160,y)); y+=60
        p.blit(self.font.render('← → para elegir, Enter para jugar',True,(200,220,240)),(280,560))
