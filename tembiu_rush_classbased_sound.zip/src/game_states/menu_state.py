# -*- coding: utf-8 -*-
import pygame
from ..ui.button import Button

class MenuState:
    def __init__(self,game):
        self.game=game; cx,cy=game.size[0]//2, game.size[1]//2
        self.btn_jugar=Button('Jugar',(cx-120,cy,240,56),lambda:game.set_state('historia'), sound=game.sound)
        self.btn_instr=Button('Instrucciones',(cx-120,cy+70,240,56),lambda:game.set_state('instrucciones'), sound=game.sound)
        self.btn_salir=Button('Salir',(cx-120,cy+140,240,56),game.quit, sound=game.sound)
        self.font=pygame.font.SysFont(None, 64)
        game.sound.play_music("ambient/menu_music.ogg")

    def handle(self,e):
        self.btn_jugar.handle(e); self.btn_instr.handle(e); self.btn_salir.handle(e)
    def update(self,dt): pass
    def draw(self,p):
        p.fill((32,60,92))
        title=self.font.render("Tembi'u Rush",True,(255,255,255))
        p.blit(title, title.get_rect(center=(self.game.size[0]//2,160)))
        for b in (self.btn_jugar,self.btn_instr,self.btn_salir): b.draw(p)
