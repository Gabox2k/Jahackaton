# -*- coding: utf-8 -*-
import pygame
class HistoriaState:
    def __init__(self,game): self.game=game; self.font=pygame.font.SysFont(None,28)
    def handle(self,e):
        if e.type==pygame.KEYDOWN: self.game.set_state('seleccion_mapa')
    def update(self,dt): pass
    def draw(self,p):
        p.fill((16,24,32))
        lines=['En Asunción, dos cocineros deben salvar su trabajo...','¡Completar 3 pedidos perfectos!','Pulsa una tecla para elegir el mapa.']
        y=160
        for t in lines: p.blit(self.font.render(t,True,(230,230,230)),(100,y)); y+=36
