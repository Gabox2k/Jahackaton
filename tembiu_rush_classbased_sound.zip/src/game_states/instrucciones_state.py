# -*- coding: utf-8 -*-
import pygame
class InstruccionesState:
    def __init__(self,game): self.game=game; self.font=pygame.font.SysFont(None,28)
    def handle(self,e):
        if e.type==pygame.KEYDOWN: self.game.set_state('menu')
    def update(self,dt): pass
    def draw(self,p):
        p.fill((20,20,20))
        textos=['P1: WASD + E','P2: Flechas + Enter','Objetivo: completar 3 pedidos.','Pulsa tecla para volver.']
        y=120
        for t in textos: p.blit(self.font.render(t,True,(240,240,240)),(80,y)); y+=40
