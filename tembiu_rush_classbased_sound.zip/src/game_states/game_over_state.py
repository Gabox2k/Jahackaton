# -*- coding: utf-8 -*-
import pygame
class GameOverState:
    def __init__(self,game,ganado,saldo):
        self.game=game; self.ganado=ganado; self.saldo=saldo
        self.big=pygame.font.SysFont(None,48); self.small=pygame.font.SysFont(None,28)
        theme = "ambient/victory_theme.ogg" if ganado else "ui/game_over.wav"
        game.sound.play_music(theme, loop=0)
    def handle(self,e):
        if e.type==pygame.KEYDOWN: self.game.set_state('menu')
    def update(self,dt): pass
    def draw(self,p):
        p.fill((0,30,30)); txt='VICTORIA' if self.ganado else 'DERROTA'; color=(120,255,160) if self.ganado else (255,120,120)
        p.blit(self.big.render(txt,True,color), (self.game.size[0]//2-120,200))
        p.blit(self.small.render(f"Saldo: ₲ {self.saldo:,}".replace(",","."),True,(230,230,230)), (460,320))
        p.blit(self.small.render('Pulsa una tecla para volver al menú',True,(230,230,230)), (360,520))
