# -*- coding: utf-8 -*-
import pygame
from .item import Ingrediente, Plato
class Estacion:
    def __init__(self,nombre,tipo,rect, sound=None):
        self.nombre=nombre; self.tipo=tipo; self.rect=pygame.Rect(rect); self.buffer=[]; self.sound=sound
    def interactuar(self,jugador):
        if self.tipo=='heladera':
            if self.sound: self.sound.play('pickup')
            jugador.inventario.append(Ingrediente('carne'))
        elif self.tipo=='mesa_corte':
            any_change=False
            for i in jugador.inventario:
                if i.estado=='crudo': i.estado='cortado'; any_change=True
            if any_change and self.sound: self.sound.play('chop')
        elif self.tipo in ('olla','sarten'):
            changed=False
            for i in jugador.inventario:
                if i.estado in ('crudo','cortado'): i.estado='cocido'; changed=True
            if changed and self.sound: self.sound.play('cook')
        elif self.tipo=='platos':
            p=Plato('plato')
            for i in list(jugador.inventario): p.agregar(i)
            jugador.inventario.clear(); self.buffer.append(p)
        elif self.tipo=='entrega':
            self.buffer.append('ENTREGAR')
