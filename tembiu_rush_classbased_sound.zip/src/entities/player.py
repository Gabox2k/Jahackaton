# -*- coding: utf-8 -*-
import pygame
class Jugador:
    def __init__(self,nombre,rect,teclas):
        self.nombre=nombre; self.rect=pygame.Rect(rect); self.teclas=teclas; self.inventario=[]
    def update(self,keys,dt,solidos,lim):
        vel=4; dx=(keys[self.teclas['right']]-keys[self.teclas['left']])*vel
        dy=(keys[self.teclas['down']]-keys[self.teclas['up']])*vel
        self.rect.x+=dx
        for s in solidos:
            if self.rect.colliderect(s.rect):
                if dx>0:self.rect.right=s.rect.left
                elif dx<0:self.rect.left=s.rect.right
        self.rect.x=max(0,min(self.rect.x,lim[0]-self.rect.width))
        self.rect.y+=dy
        for s in solidos:
            if self.rect.colliderect(s.rect):
                if dy>0:self.rect.bottom=s.rect.top
                elif dy<0:self.rect.top=s.rect.bottom
        self.rect.y=max(0,min(self.rect.y,lim[1]-self.rect.height))
    def accionar(self,estaciones):
        for e in estaciones:
            if self.rect.colliderect(e.rect.inflate(10,10)): e.interactuar(self)
