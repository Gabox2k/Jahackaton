# -*- coding: utf-8 -*-
from enum import Enum, auto
class Accion(Enum): NINGUNA=0; CORTAR=auto(); COCINAR=auto(); EMPLATAR=auto(); ENTREGAR=auto()
class Ingrediente:
    def __init__(self,nombre,estado='crudo'): self.nombre=nombre; self.estado=estado
    def __repr__(self): return f"{self.nombre}({self.estado})"
class Plato:
    def __init__(self,nombre,ingredientes=None): self.nombre=nombre; self.ingredientes=ingredientes or []
    def agregar(self,ing): self.ingredientes.append(ing)
