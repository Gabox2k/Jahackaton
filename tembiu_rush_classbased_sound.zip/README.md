# Tembi'u Rush – Con Sonidos Integrados

Proyecto organizado por estados y clases, con **SoundManager** para música y SFX:
- Música por estado (menú, juego, victoria/derrota).
- SFX para UI (click/hover) y gameplay (cortar, cocinar, pickup, entregar ok/fail, warning).

## Ejecutar
```bash
pip install -r requirements.txt
python -m src.main
```

## Sonidos
Coloca tus archivos reales en:
```
assets/sounds/ui/
assets/sounds/gameplay/
assets/sounds/ambient/
```
Se incluyen *placeholders* vacíos para que el juego corra sin errores aunque aún no tengas los audios definitivos.
